"""Opt-in tests against real PostgreSQL, isolated in a disposable schema."""
import os
import uuid
import pytest
import psycopg
from psycopg import sql
from app.config.settings import get_settings
from app.database.postgres import PostgresConnection
from app.database.migrations import run_migrations, verify_schema, MIGRATIONS
from app.database.models import Business, PipelineRun, PipelineRunEvent
from app.database.repositories import BusinessRepository, PipelineRunRepository, PipelineRunEventRepository
from app.database.prospects import ProspectRepository

pytestmark = pytest.mark.skipif(os.environ.get("RUN_POSTGRES_TESTS") != "1", reason="Set RUN_POSTGRES_TESTS=1 for real PostgreSQL integration")


def test_real_postgres_permanent_deletion(postgres,monkeypatch):
    from unittest.mock import Mock
    from app.api.services.deletion import preview,delete
    c=postgres;run_migrations(c)
    run=PipelineRun(market='Deletion QA',vertical='dentists',target=5,status='COMPLETED');PipelineRunRepository(c).create(run)
    b=Business(name='Postgres deletion QA',normalized_name='postgres deletion qa',vertical='dentists',run_id=run.id,website='https://delete-qa.invalid');BusinessRepository(c).insert(b)
    ProspectRepository(c).observe(b);c.commit()
    monkeypatch.setattr('app.api.services.deletion.artifact_storage',lambda:Mock())
    p=preview(c,'scan',str(run.id));c.commit()
    assert delete(c,'scan',str(run.id),'DELETE',p['token'],'a@example.com')['deleted']
    assert c.execute('SELECT COUNT(*) FROM businesses').fetchone()[0]==0
    assert c.execute('SELECT COUNT(*) FROM prospects').fetchone()[0]==0
    assert c.execute('SELECT COUNT(*) FROM pipeline_runs').fetchone()[0]==0


@pytest.fixture
def postgres():
    url = get_settings().database_url
    assert url, "DATABASE_URL is required"
    schema = "leadengine_test_" + uuid.uuid4().hex
    admin = psycopg.connect(url, autocommit=True)
    admin.execute(sql.SQL("CREATE SCHEMA {}").format(sql.Identifier(schema)))
    conn = None
    try:
        conn = PostgresConnection(url, schema=schema)
        yield conn
    finally:
        if conn:
            conn.close()
        admin.execute(sql.SQL("DROP SCHEMA {} CASCADE").format(sql.Identifier(schema)))
        admin.close()


def test_real_postgres_repositories_and_shared_workflow(postgres):
    conn = postgres
    assert run_migrations(conn) == len(MIGRATIONS)
    assert run_migrations(conn) == 0
    verify_schema(conn)
    runs = PipelineRunRepository(conn)
    run = PipelineRun(market="Austin", vertical="dentists", target=5)
    run_id = runs.create(run)
    business = Business(name="Independent Dental", normalized_name="independent dental", vertical="dentists", city="Austin", run_id=run_id, website="https://independent.example")
    BusinessRepository(conn).insert(business)
    assert BusinessRepository(conn).get_by_id(business.id).name == business.name
    repo = ProspectRepository(conn)
    prospect_id = repo.observe(business)
    repo.workflow(prospect_id, "a@example.com", lead_status="SHORTLISTED", assigned_to="b@example.com")
    repo.add_note(prospect_id, "b@example.com", "Public booking flow needs work.")
    event = PipelineRunEvent(run_id=run_id, stage="TEST", event_type="TEST", message="Persisted across processes")
    PipelineRunEventRepository(conn).create(event)
    conn.commit()
    dossier = repo.dossier(business.id)
    assert dossier["assigned_to"] == "b@example.com"
    assert dossier["lead_status"] == "SHORTLISTED"
    assert dossier["notes"][0]["created_by"] == "b@example.com"
    assert PipelineRunEventRepository(conn).list_by_run(run_id)[0].message == event.message
    assert BusinessRepository(conn).search_leads()[1] == 1
    run.status = "COMPLETED"
    runs.update(run)
    conn.commit()
    assert runs.get_by_id(run_id).status == "COMPLETED"
    # Phase 3.5 is additive: existing assignment and notes survive LOST, while
    # report versions belong to the same canonical prospect on PostgreSQL.
    repo.workflow(prospect_id,"a@example.com",lead_status="LOST")
    from app.reports.service import create_report
    first=create_report(conn,business.id,prospect_id,'a@example.com')
    assert create_report(conn,business.id,prospect_id,'a@example.com')['id']==first['id']
    conn.execute("UPDATE client_reports SET status='READY' WHERE id=?",(first['id'],))
    second=create_report(conn,business.id,prospect_id,'a@example.com')
    conn.commit()
    assert first['version']==1 and second['version']==2
    assert repo.dossier(business.id)['lead_status']=='LOST'
    assert repo.dossier(business.id)['notes'][0]['body']=='Public booking flow needs work.'


def test_worker_session_lock_survives_commit_and_releases_on_close():
    url=get_settings().database_url
    first=PostgresConnection(url,session_bound=True)
    second=PostgresConnection(url,session_bound=True)
    lock=int(uuid.uuid4().hex[:7],16)
    try:
        assert first.execute('SELECT pg_try_advisory_lock(6919444,?)',(lock,)).fetchone()[0]
        first.commit()
        assert not second.execute('SELECT pg_try_advisory_lock(6919444,?)',(lock,)).fetchone()[0]
        second.commit();first.close();first=None
        assert second.execute('SELECT pg_try_advisory_lock(6919444,?)',(lock,)).fetchone()[0]
    finally:
        if first:first.close()
        second.close()


def test_real_postgres_schema9_views_and_target_storage(postgres):
    """Disposable-schema acceptance only; production public schema is untouched."""
    from app.automation.service import reconcile
    from app.automation.views import search
    from app.automation.settings import save_targets,effective_settings
    c=postgres;run_migrations(c)
    run=PipelineRun(market='Controlled London',vertical='dentists',target=1);PipelineRunRepository(c).create(run)
    b=Business(name='Controlled permanent lead',normalized_name='controlled permanent lead',vertical='dentists',city='London',country='United Kingdom',phone='+442055501234',website='https://controlled.invalid',run_id=run.id,processing_status='QUALIFIED')
    BusinessRepository(c).insert(b);pid=ProspectRepository(c).observe(b)
    reconcile(c)
    page=search(c,{'country':'United Kingdom','email_availability':'no'},'manual',1,25)
    assert page['total']==1 and page['items'][0]['prospect_id']==pid and page['counts']['today']==1
    save_targets(c,{'daily_qualified_lead_target':3,'daily_email_target':2,'max_hour':2,'max_day':5},'system');c.commit()
    assert effective_settings(c).daily_qualified_lead_target==3


def test_real_postgres_enabled_queue_duplicate_claim(postgres,monkeypatch):
    from unittest.mock import Mock
    from datetime import datetime,timezone
    from app.automation import service as automation
    from app.mail import service as mail
    from app.mail.config import MailSettings
    from app.database.prospects import now
    c=postgres;run_migrations(c)
    config=MailSettings(_env_file=None,EMAIL_PROVIDER='hostinger',EMAIL_SEND_MODE='test',EMAIL_TEST_RECIPIENT='contact@planebyte.com',EMAIL_SENDING_ENABLED=True,AUTO_EMAIL_ENABLED=True,MAX_EMAILS_PER_DAY=100,DAILY_EMAIL_TARGET=100)
    monkeypatch.setattr(automation,'mail_settings',lambda:config);monkeypatch.setattr(mail,'mail_settings',lambda:config)
    monkeypatch.setattr(automation,'business_hours',lambda *args:True)
    transport=Mock();monkeypatch.setattr(mail,'provider',lambda:transport)
    from campaign_fixtures import campaign,qualify
    cid=campaign(c)
    run=PipelineRun(market='Controlled',vertical='dentists',target=1,status='COMPLETED');PipelineRunRepository(c).create(run)
    b=Business(name='Controlled queue',normalized_name='controlled queue',vertical='dentists',city='London',run_id=run.id,website='https://controlled.invalid',public_email='contact@planebyte.com',processing_status='QUALIFIED')
    c.execute('UPDATE pipeline_runs SET campaign_id=? WHERE id=?',(cid,run.id))
    BusinessRepository(c).insert(b);qualify(c,b);pid=ProspectRepository(c).observe(b)
    c.execute("INSERT INTO contacts(business_id,contact_type,contact_value,source_url,is_valid,is_public_business_contact) VALUES(?,'email',?,?,1,1)",(b.id,b.public_email,b.website+'/contact'))
    c.execute("INSERT INTO business_intelligence(business_id,prospect_id,classification_version,business_scale,scale_reason,scale_confidence,footprint_json,commercial_fit,commercial_reason,created_at) VALUES(?,?,'qa','SMALL_GROUP','fixture',1,'{}','HIGH','fixture',?)",(b.id,pid,now()))
    c.execute("INSERT INTO findings(business_id,finding_code,category,severity,title,description) VALUES(?,'qa','SEO','LOW','Controlled finding','Stored controlled finding')",(b.id,))
    c.execute('UPDATE automation_controls SET email_paused=0');automation.reconcile(c);c.commit()
    import json
    from datetime import datetime,timezone
    from app.mail.templates import seed
    seed(c)
    c.execute("INSERT INTO workflow_runs(id,name,kind,status,configuration_json,created_by,created_at,requested,request_key,campaign_id) VALUES('pg-explicit','Controlled','OUTREACH','RUNNING',?,'system',?,1,'pg-explicit',?)",(json.dumps({'campaign_id':cid,'pitch_types':['WEBSITE'],'max_hour':10,'max_day':100,'window_start':'00:00','window_end':'23:59','recipient_timezone':False}),now(),cid))
    queued='pg-explicit-message'
    payload={'campaign_id':cid,'pitch_types':['WEBSITE'],'to_address':'contact@planebyte.com','subject':'Controlled transport','body_text':'Controlled transport fixture','confirmation':'SEND','idempotency_key':queued,'message_type':'MANUAL_REPLY'}
    payload['preview_token']=mail.preview(c,pid,'system',payload)['preview_token']
    c.execute("INSERT INTO outreach_run_items(id,run_id,prospect_id,business_id,status,payload_json,idempotency_key,created_at,updated_at) VALUES('pg-item','pg-explicit',?,?,'READY',?,?,?,?)",(pid,b.id,json.dumps(payload),queued,now(),now()));automation.reconcile(c);c.commit()
    monkeypatch.setattr(automation,'utc_now',lambda:datetime(2026,11,2,10,tzinfo=timezone.utc))
    assert automation.outreach_tick(c,execution_id='pg-explicit')['status']=='SENT'

    # A restarted independent DB connection sees the same durable spacing guard.
    second=PostgresConnection(get_settings().database_url,schema=c.schema)
    try:assert automation.outreach_tick(second,execution_id='pg-explicit')['status']=='PAUSED_OR_WAITING'
    finally:second.close()
    assert transport.send_message.call_count==1
    assert c.execute("SELECT COUNT(*) FROM email_messages WHERE status='SENT'").fetchone()[0]==1


def test_real_postgres_legacy_company_alias_rediscovery(postgres):
    c=postgres;run_migrations(c);ids=[]
    for city in ('London','Bristol'):
        run=PipelineRun(market=city,vertical='home_services',target=1);PipelineRunRepository(c).create(run)
        b=Business(name='Controlled alias company',normalized_name='controlled alias company',vertical='home_services',city=city,domain='controlled-alias.invalid',website='https://controlled-alias.invalid',public_email='contact@controlled-alias.invalid',run_id=run.id)
        BusinessRepository(c).insert(b);ids.append(ProspectRepository(c).observe(b))
        if city=='London':c.execute("DELETE FROM business_identities WHERE evidence_type IN ('COMPANY_DOMAIN','COMPANY_EMAIL')")
    assert ids[0]==ids[1]
    assert c.execute('SELECT COUNT(*) FROM prospects').fetchone()[0]==1
    assert c.execute('SELECT COUNT(*) FROM prospect_observations').fetchone()[0]==2
    assert c.execute("SELECT COUNT(*) FROM business_identities WHERE evidence_type IN ('COMPANY_DOMAIN','COMPANY_EMAIL')").fetchone()[0]==2


def test_manual_schedule_duplicate_dispatch_and_schema10_preserves_rows(postgres,monkeypatch):
    import asyncio,json
    from app.workflows import service
    from app.api.routes.workflows import Run,Schedule,save_schedule
    from app.mail.config import MailSettings
    c=postgres;run_migrations(c)
    assert c.execute('SELECT MAX(version) FROM schema_migrations').fetchone()[0]==len(MIGRATIONS)
    settings=MailSettings(_env_file=None,AUTO_SCAN_ENABLED=True)
    monkeypatch.setattr(service,'mail_settings',lambda:settings)
    calls=[]
    async def start(*args):calls.append(args)
    monkeypatch.setattr('app.api.services.scan_manager.scan_manager.executor.start',start)
    r=Run(name='Disposable schema scan',kind='SCAN',target=2)
    schedule=Schedule(name='Disposable schedule',configuration=r,enabled=False,timezone='Europe/London',frequency='daily',start_at='2026-01-01T06:00:00+00:00')
    sid=save_schedule(c,schedule,'owner@example.com')['id']
    c.execute("UPDATE automation_schedules SET enabled=1,next_run_at='2026-01-01T06:00:00+00:00' WHERE id=?",(sid,));c.execute('UPDATE automation_controls SET scan_paused=0');c.commit()
    assert len(asyncio.run(service.dispatch(c))['scheduled_runs_started'])==1
    assert asyncio.run(service.dispatch(c))['scheduled_runs_started']==[]
    assert len(calls)==1
    assert c.execute('SELECT COUNT(*) FROM automation_schedule_runs').fetchone()[0]==1
    workflow=c.execute('SELECT id FROM workflow_runs').fetchone()[0]
    assert service.detail(c,workflow)['scans'][0]['status']=='QUEUED'
    assert run_migrations(c)==0


def test_campaign_schema11_preserves_history_and_legacy_intent(postgres,monkeypatch):
    from test_campaign_outreach import migration_preservation
    migration_preservation(postgres,monkeypatch)


def test_campaign_operations_postgres_audience_and_messages(postgres):
    from campaign_fixtures import campaign,lead
    from app.workflows.campaigns import audience,campaign_summary
    from app.api.routes import operations
    from app.api.routes.workflows import Run
    from app.workflows import service
    from test_campaign_outreach import message
    c=postgres;run_migrations(c);cid=campaign(c,'Postgres audience')
    b,pid=lead(c,cid,800);lead(c,cid,801,email=False)
    assert audience(c,cid)['qualified']==2
    r=service.create(c,Run(kind='OUTREACH',campaign_id=cid,max_day=1).model_dump(),'owner')
    assert service.detail(c,r['id'])['items_total']==2
    message(c,pid);c.commit()
    result=operations.messages(search='',campaign_id=cid,pitch='',status='',engagement='',reply_state='',sender='',direction='OUTBOUND',created_from='',created_to='',page=1,page_size=25,c=c)
    # Unlinked legacy fixture message remains visible globally, never relabeled as campaign outreach.
    assert result['total']==0
    result=operations.messages(search='',campaign_id='',pitch='',status='',engagement='',reply_state='',sender='',direction='OUTBOUND',created_from='',created_to='',page=1,page_size=25,c=c)
    assert result['total']==1
    assert campaign_summary(c,cid)['total_accounted']==2
    assert operations.views(c)==[]


def test_foundation_postgres_review_queries(postgres):
    from app.workflows.quality import quality,reviews
    c=postgres;run_migrations(c)
    assert quality(c)['master_leads']==0
    assert reviews(c,search='owner',size=1)['total']==0
