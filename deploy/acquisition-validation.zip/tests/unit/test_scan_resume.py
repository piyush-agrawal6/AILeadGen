import ast,asyncio,textwrap,importlib.util
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import Mock,AsyncMock
import pytest

SOURCE=Path(importlib.util.find_spec('app.pipeline.runner').origin).read_text()
TREE=ast.parse(SOURCE)
def function(name):
    node=next(n for n in ast.walk(TREE) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name)
    return textwrap.dedent(ast.get_source_segment(SOURCE,node))

@pytest.mark.parametrize('campaign_cancelled,run_cancelled,elapsed,exception',[
    (False,False,0,None),(False,False,10799,None),
    (False,False,10801,TimeoutError),(True,False,0,asyncio.CancelledError),
    (False,True,0,asyncio.CancelledError),
])
def test_resume_budget_and_cancellation(campaign_cancelled,run_cancelled,elapsed,exception):
    conn=Mock()
    def execute(query,args):
        if 'FROM pipeline_runs' in query:
            row={'status':'RUNNING','cancellation_requested':run_cancelled}
        else:
            # Deliberately old campaign, matching the failed production resume.
            row=('2020-01-01T00:00:00+00:00',campaign_cancelled) if 'created_at' in query else (campaign_cancelled,)
        return NS(fetchone=lambda:row)
    conn.execute.side_effect=execute
    env={'run_configuration':{},'time':NS(time=lambda:elapsed),'start_time':0,'self':NS(settings=NS(max_scan_runtime_minutes=180)),
         'conn':conn,'pipeline_run':NS(id=4),'asyncio':asyncio}
    exec(function('runtime_limit')+'\n'+function('check_cancellation'),env)
    if exception:
        with pytest.raises(exception):env['check_cancellation']()
    else:env['check_cancellation']()

@pytest.mark.parametrize('resume,cached',[(True,True),(True,False),(False,True)])
def test_committed_lighthouse_reuse(resume,cached):
    saved=NS(performance_score=45)
    repo=Mock();repo.get_by_business_id.return_value=saved if cached else None
    audit=AsyncMock(return_value=NS(performance_score=65,model_dump=lambda:{'performance_score':65}))
    env={'Business':object,'all_profiles':{42:NS(reachable=True,final_url='https://example.com')},
         'reuse':NS(get=Mock(return_value=None),put=Mock(),mode='INCREMENTAL'),'probe_results':{},
         'lh_sem':asyncio.Semaphore(1),'lh_repo':repo,'prior':[1] if resume else [],
         'run_lighthouse_audit':audit,'conn':Mock(),'lh_results':{},'lh_pool':[1],
         'emit_event':Mock(),'self':NS(settings=NS(audit=NS(lighthouse_timeout_seconds=30)))}
    exec('def factory():\n    lh_count=0\n'+textwrap.indent(function('run_lh_single'),'    ')+'\n    return run_lh_single\n',env)
    asyncio.run(env['factory']()(NS(id=42,website='https://example.com')))
    reused=resume and cached
    assert audit.await_count==(0 if reused else 1)
    assert repo.upsert.call_count==(0 if reused else 1)
    assert env['lh_results'][42].performance_score==(45 if reused else 65)
