"""New Maps qualification gates: no contactable opportunity means no deep work."""
import asyncio,json
from unittest.mock import AsyncMock
import pytest
from test_automation import db
from campaign_fixtures import campaign
from app.database.models import Business,PipelineRun
from app.database.repositories import BusinessRepository,PipelineRunRepository
from app.database.prospects import ProspectRepository
from app.enrichment.http_probe import ProbeResult
from app.pipeline.reuse import AnalysisReuse
from app.qualification import resource_gate as gate

OPTIONS={'qualification_flow_version':1,'qualification_mode':'BALANCED','opportunities':['WEBSITE','SEO','SECURITY'],'deep_audit_budget':2,'preliminary_opportunity_threshold':10,'qualified_score_threshold':35}

def candidate(c,n,html,cid=None):
 cid=cid or campaign(c,'Resource gate')
 run=PipelineRun(market='Bristol, United Kingdom',vertical='dentists',target=1,status='RUNNING');PipelineRunRepository(c).create(run);c.execute('UPDATE pipeline_runs SET campaign_id=? WHERE id=?',(cid,run.id))
 b=Business(name=f'Independent Dental {n}',normalized_name=f'independent dental {n}',vertical='dentists',subcategory='dental_clinic',country='United Kingdom',city='Bristol',website=f'https://dental{n}.test',domain=f'dental{n}.test',source_tags='{}',run_id=run.id)
 BusinessRepository(c).insert(b);ProspectRepository(c).observe(b,cid,'owner');c.commit()
 probe=ProbeResult(requested_url=b.website,final_url=b.website,reachable=True,http_status=200,https_enabled=True,html_content=html,response_headers={})
 return b,probe,AnalysisReuse(c,run.id,OPTIONS)

def opportunity(points=25):return {'website_opportunity_score':points,'seo_opportunity_score':0,'security_opportunity_score':0,'evidence':{'WEBSITE':[{'code':'NO_VIEWPORT','points':points,'source_url':'https://dental1.test','observed_at':'2026-11-02'}]}}

@pytest.mark.parametrize('mode',['EXPLORATORY','BALANCED','STRICT'])
def test_no_email_blocks_every_mode_and_preserves_canonical(db,monkeypatch,mode):
 b,p,reuse=candidate(db,1,'<h1>Dental</h1>')
 contact=AsyncMock(return_value=[]);audit=AsyncMock(side_effect=AssertionError('No email must not reach opportunity/deep analysis'))
 monkeypatch.setattr(gate,'contact_pages',contact);monkeypatch.setattr(gate,'analyze_opportunities',audit)
 selected,counts=asyncio.run(gate.early_filter(db,[b],{b.id:p},reuse,{**OPTIONS,'qualification_mode':mode},'dentists'))
 assert selected==[] and counts['no_email']==1 and counts['deep_audits_skipped']==1
 saved=db.execute('SELECT * FROM businesses WHERE id=?',(b.id,)).fetchone();assert saved['rejection_reason']=='NO_EMAIL' and saved['processing_status']!='QUALIFIED'
 assert json.loads(saved['source_tags_json'])['qualification']['email_searched_at']
 assert db.execute('SELECT COUNT(*) FROM prospects').fetchone()[0]==1
 assert db.execute('SELECT COUNT(*) FROM lighthouse_results').fetchone()[0]==0
 assert not audit.called
 # Negative contact search is cached; the next identical scan does not refetch contact pages.
 reuse2=AnalysisReuse(db,b.run_id,OPTIONS)
 asyncio.run(gate.early_filter(db,[b],{b.id:p},reuse2,OPTIONS,'dentists'))
 assert contact.await_count==1


def test_email_plus_one_website_opportunity_is_sufficient(db,monkeypatch):
 b,p,reuse=candidate(db,2,'<h1>Dental</h1><a href="mailto:office@dental2.test">Contact</a>')
 monkeypatch.setattr(gate,'check_email_dns',lambda *a:('MX',True));monkeypatch.setattr(gate,'analyze_opportunities',lambda *a,**k:opportunity())
 selected,counts=asyncio.run(gate.early_filter(db,[b],{b.id:p},reuse,OPTIONS,'dentists'))
 assert selected==[b] and counts['email_valid']==1 and gate.meaningful(opportunity(),OPTIONS)
 assert b.public_email=='office@dental2.test'
 assert db.execute("SELECT source_type,is_public_business_contact FROM contacts WHERE business_id=?",(b.id,)).fetchone()[0]=='EARLY_EMAIL'
 assert not gate.meaningful(opportunity(0),OPTIONS)
 assert not gate.meaningful(opportunity(25),{**OPTIONS,'qualification_mode':'STRICT'})


def test_email_without_opportunity_and_invalid_domain_skip_deep(db,monkeypatch):
 b,p,reuse=candidate(db,3,'<h1>Dental</h1><a href="mailto:office@dental3.test">Contact</a>')
 monkeypatch.setattr(gate,'check_email_dns',lambda *a:('MX',True));monkeypatch.setattr(gate,'analyze_opportunities',lambda *a,**k:opportunity(0))
 selected,_=asyncio.run(gate.early_filter(db,[b],{b.id:p},reuse,OPTIONS,'dentists'))
 assert not selected and b.rejection_reason=='NO_MEANINGFUL_OPPORTUNITY'
 b,p,reuse=candidate(db,4,'<a href="mailto:office@dental4.test">Email</a>')
 monkeypatch.setattr(gate,'check_email_dns',lambda *a:('NXDOMAIN',False));monkeypatch.setattr(gate,'contact_pages',AsyncMock(return_value=[]))
 selected,counts=asyncio.run(gate.early_filter(db,[b],{b.id:p},reuse,OPTIONS,'dentists'))
 assert not selected and counts['invalid_email']==1 and b.rejection_reason=='INVALID_EMAIL'


def test_suppression_precedes_email_search(db,monkeypatch):
 b,p,reuse=candidate(db,5,'<a href="mailto:office@dental5.test">Email</a>')
 db.execute("UPDATE prospects SET lead_status='DO_NOT_CONTACT'")
 dns=AsyncMock(side_effect=AssertionError('Suppressed identity must stop early'));monkeypatch.setattr(gate,'check_email_dns',dns)
 selected,_=asyncio.run(gate.early_filter(db,[b],{b.id:p},reuse,OPTIONS,'dentists'))
 assert not selected and b.rejection_reason=='SUPPRESSED' and not dns.called


def test_lighthouse_requires_actual_performance_indicators():
 p=ProbeResult(requested_url='https://example.test',reachable=True,html_content='<h1>Small page</h1>')
 assert not gate.lighthouse_useful(p)
 p.html_content='<script></script>'*12
 assert gate.lighthouse_useful(p)


def test_new_schedule_requires_explicit_source_and_firecrawl_review():
 from app.api.routes.workflows import Run,Schedule
 from pydantic import ValidationError
 common={'name':'Daily','frequency':'daily','start_at':'2026-12-01T09:00:00+05:30'}
 with pytest.raises(ValidationError,match='Select the scan source'):Schedule(**common,configuration={'kind':'SCAN'})
 assert Schedule(**common,configuration={'kind':'SCAN','scan_source':'OVERTURE'}).configuration.scan_source=='OVERTURE'
 with pytest.raises(ValidationError,match='Interpret and review'):Run(kind='SCAN',scan_source='FIRECRAWL')


@pytest.mark.parametrize('late_finalize',[False,True])
def test_maps_full_runner_enforces_email_before_crawl_and_reuses_analysis(tmp_path,monkeypatch,late_finalize):
 from app.database.connection import get_connection,db_session
 from app.database.migrations import run_migrations
 from app.acquisition.pipeline import CandidateCoordinator
 from app.acquisition.models import ProcessingOptions
 from app.acquisition.policy import DISCOVERY
 from app.pipeline.runner import PipelineRunner
 from app.enrichment.crawler import CrawlResult
 from app.enrichment.contacts import extract_contacts_from_html
 path=tmp_path/'maps.db';c=get_connection(path);run_migrations(c);c.close()
 if late_finalize:
  from app.pipeline import runner as module
  clock=[module.time.time()];original=module.store_opportunities
  def store(*args,**kwargs):
   value=original(*args,**kwargs);clock[0]+=2;return value
  monkeypatch.setattr(module.time,'time',lambda:clock[0]);monkeypatch.setattr(module,'store_opportunities',store)
 htmls={
  'https://dental10.test':'<html><head><title>Bristol Dental Clinic</title></head><body><h1>Bristol independent dental practice</h1><a href="mailto:office@dental10.test">Contact</a></body></html>',
  'https://dental11.test':'<html><h1>Bristol independent dental practice</h1></html>'}
 async def probe(url,**kw):return ProbeResult(requested_url=url,final_url=url,reachable=True,http_status=200,https_enabled=True,html_content=htmls[url],response_headers={})
 crawled=[]
 async def crawl(self,start_url,**kw):
  crawled.append(start_url);r=CrawlResult(start_url);r.homepage_html=htmls[start_url];r.all_htmls={start_url:htmls[start_url]};r.pages_crawled=1;r.contacts=extract_contacts_from_html(htmls[start_url],start_url);return r
 monkeypatch.setattr('app.pipeline.runner.probe_website',probe);monkeypatch.setattr('app.enrichment.crawler.WebsiteCrawler.crawl',crawl)
 monkeypatch.setattr(gate,'contact_pages',AsyncMock(return_value=[]));monkeypatch.setattr(gate,'check_email_dns',lambda *a:('MX',True));monkeypatch.setattr('app.pipeline.runner.check_email_dns',lambda *a,**k:('MX',True))
 monkeypatch.setattr('app.pipeline.runner.enrich_social',AsyncMock(return_value=([],{'enabled':False})));monkeypatch.setattr('app.enrichment.screenshot.capture_website',AsyncMock(return_value=None))
 monkeypatch.setenv('SOCIAL_ENRICHMENT_ENABLED','false');monkeypatch.setenv('SOCIAL_ACTIVITY_ENABLED','false')
 for attempt in range(2):
  businesses=[Business(name=f'Independent Dental {n}',normalized_name=f'independent dental {n}',vertical='dentists',subcategory='dental_clinic',country='United Kingdom',city='Bristol',website=f'https://dental{n}.test',domain=f'dental{n}.test',source_overture=True) for n in (10,11)]
  coordinator=CandidateCoordinator(businesses,ProcessingOptions(default_vertical='dentists'),DISCOVERY)
  runner=PipelineRunner(db_path=path,output_dir=tmp_path/'out',discovery_coordinator=coordinator)
  config={**OPTIONS,'source_type':'OVERTURE','processing_policy':'DISCOVERY_QUALIFIED','target':1,'business_scales':['LOCAL','SMALL_GROUP','MID_MARKET','REGIONAL'],'results':'include_previous','lighthouse_budget':0,**({'max_runtime_seconds':1} if late_finalize else {})}
  run=asyncio.run(runner.run(market='Bristol, United Kingdom',vertical='dentists',target=1,enable_lighthouse=False,run_configuration=config))
  assert run.status=='COMPLETED' and run.qualified==1
  with db_session(path) as c:
   no_mail=c.execute("SELECT processing_status,rejection_reason FROM businesses WHERE run_id=? AND domain='dental11.test'",(run.id,)).fetchone();assert no_mail['processing_status']!='QUALIFIED' and no_mail['rejection_reason']=='NO_EMAIL'
   assert c.execute('SELECT COUNT(*) FROM lighthouse_results').fetchone()[0]==0
   assert c.execute('SELECT COUNT(*) FROM email_messages').fetchone()[0]==0
 assert crawled==['https://dental10.test']
 with db_session(path) as c:assert c.execute("SELECT COUNT(*) FROM analysis_operations WHERE operation='REUSED'").fetchone()[0]>0


def test_deep_audit_budget_bounds_valid_promising_businesses(db,monkeypatch):
 businesses=[];probes={};reuse=None
 for n in (21,22,23):
  b,p,r=candidate(db,n,f'<a href="mailto:office@dental{n}.test">Email</a>');businesses.append(b);probes[b.id]=p;reuse=reuse or r
 monkeypatch.setattr(gate,'check_email_dns',lambda *a:('MX',True));monkeypatch.setattr(gate,'analyze_opportunities',lambda *a,**k:opportunity())
 selected,counts=asyncio.run(gate.early_filter(db,businesses,probes,reuse,{**OPTIONS,'deep_audit_budget':1},'dentists'))
 assert len(selected)==1 and counts['email_valid']==3 and counts['deep_audits_skipped']==2
 assert sum(b.rejection_reason=='DEEP_AUDIT_BUDGET' for b in businesses)==2


def test_large_no_email_pool_flags_anomaly_without_deep_analysis(tmp_path,monkeypatch):
 from app.database.connection import get_connection,db_session
 from app.database.migrations import run_migrations
 from app.acquisition.pipeline import CandidateCoordinator
 from app.acquisition.models import ProcessingOptions
 from app.acquisition.policy import DISCOVERY
 from app.pipeline.runner import PipelineRunner
 path=tmp_path/'anomaly.db';c=get_connection(path);run_migrations(c);c.close()
 businesses=[Business(name=f'Independent Dental {n}',normalized_name=f'independent dental {n}',vertical='dentists',subcategory='dental_clinic',website=f'https://anomaly{n}.test',domain=f'anomaly{n}.test',country='United Kingdom',city='Bristol',source_overture=True) for n in range(100)]
 async def probe(url,**kw):return ProbeResult(requested_url=url,final_url=url,reachable=True,http_status=200,html_content='<h1>Dental Bristol</h1>')
 monkeypatch.setattr('app.pipeline.runner.probe_website',probe);monkeypatch.setattr(gate,'contact_pages',AsyncMock(return_value=[]))
 crawl=AsyncMock(side_effect=AssertionError('No email must not crawl'));monkeypatch.setattr('app.enrichment.crawler.WebsiteCrawler.crawl',crawl)
 monkeypatch.setattr('app.pipeline.runner.enrich_social',AsyncMock(return_value=([],{})))
 runner=PipelineRunner(db_path=path,output_dir=tmp_path/'out',discovery_coordinator=CandidateCoordinator(businesses,ProcessingOptions(default_vertical='dentists'),DISCOVERY))
 with pytest.raises(gate.QualificationAnomaly):asyncio.run(runner.run('Bristol, United Kingdom','dentists',target=5,enable_lighthouse=False,run_configuration={**OPTIONS,'source_type':'OVERTURE','target':5}))
 assert crawl.await_count==0
 with db_session(path) as c:
  assert c.execute("SELECT COUNT(*) FROM businesses WHERE rejection_reason='NO_EMAIL'").fetchone()[0]==100
  assert c.execute("SELECT failure_class FROM pipeline_runs").fetchone()[0]=='QUALIFICATION_ANOMALY'
  assert c.execute('SELECT COUNT(*) FROM lighthouse_results').fetchone()[0]==0
