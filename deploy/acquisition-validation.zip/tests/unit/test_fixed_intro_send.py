import hashlib,json,uuid
from pathlib import Path
import pytest
from fastapi import HTTPException
from test_phase4 import workspace
from campaign_fixtures import campaign
from app.outreach import fixed
from app.outreach.capabilities_pdf import generate
from app.mail import service,tracking,contacted
from app.database.prospects import now

def test_same_universal_attachment_live_registry_and_duplicate_block(workspace,tmp_path,monkeypatch):
    c,b,pid,config,transport=workspace;config.mode='production';config.live_approved=True;config.from_address='planebyte@gmail.com';config.from_name='PlaneByte'
    transport.health_check.return_value={'smtp':'READY','imap':'READY'}
    cid=campaign(c);c.execute('UPDATE pipeline_runs SET campaign_id=? WHERE id=?',(cid,b.run_id));fixed.seed(c)
    pdf=generate(tmp_path/'capabilities.pdf');raw=pdf.read_bytes()
    from app.storage import LocalArtifactStorage
    storage=LocalArtifactStorage(tmp_path/'assets');key='audits/company-assets/planebyte-capabilities-v1.pdf';storage.put(key,pdf,'application/pdf');monkeypatch.setattr('app.storage.artifact_storage',lambda:storage)
    c.execute('INSERT INTO company_pdf_assets VALUES(?,?,?,?,?,?,?,?,?,?)',(fixed.ASSET_ID,'v1',contacted.organization(),'PlaneByte Capabilities & Services.pdf',key,hashlib.sha256(raw).hexdigest(),len(raw),3,1,now()))
    body=fixed.render(b.name,'PB_INTRO_01')|{'campaign_id':cid,'to_address':b.public_email,'preview_nonce':str(uuid.uuid4()),'idempotency_key':str(uuid.uuid4()),'confirmation':'SEND','track_opens':True,'track_clicks':True}
    p=service.preview(c,pid,'founder@example.com',body);assert not p['quality_issues'];assert p['pdf_attachment']['version']=='v1';body['preview_token']=p['preview_token']
    assert contacted.lookup(c,b.public_email) is None
    result=service.send(c,pid,'founder@example.com',body);assert result['status']=='SENT'
    attachment=list(transport.send_message.call_args[0][0].iter_attachments())[0];assert attachment.get_payload(decode=True)==raw
    row=contacted.lookup(c,b.public_email);assert row['send_count']==1
    assert service.send(c,pid,'founder@example.com',body)['duplicate_prevented'];transport.send_message.assert_called_once()
    with pytest.raises(HTTPException,match='ALREADY_CONTACTED'):service.preview(c,pid,'founder@example.com',body|{'idempotency_key':str(uuid.uuid4())})
    token=c.execute("SELECT token_hash FROM email_tracking_tokens WHERE message_id=? AND action='u'",(result['id'],)).fetchone()[0]
    assert c.execute('SELECT normalized_email FROM contacted_unsubscribe_tokens WHERE token_hash=?',(token,)).fetchone()[0]==b.public_email
